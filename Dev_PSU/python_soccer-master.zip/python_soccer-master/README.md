# Python Soccer
This example demonstrates the framework for a very simple python game using the Pygame package. You need to download the zip file and then open in within the correct location. Before running this script, you need to make sure that the images are in the same location as the script. It is also necessary that you first install the Pygame package with the following command on windows:

pip install pygame

If this does not work, you need to first install PIP or install pygame another way.

The game below involves a soccerball moving left and right to avoid defenders. When the ball goes out of bounds or hits a defender the game resets. Feel free to do whatever you want with it and ask us for help with anything.
